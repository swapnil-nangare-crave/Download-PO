package com.test.tejas_filetofile;

import com.sap.aii.mapping.api.*;
import com.sap.aii.mapping.lookup.*;
import com.sap.aii.mappingtool.tf7.rt.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;


public class FuncLib {

    public String upperCase(String inputString) {
        String outputString = "";
outputString = inputString.toUpperCase();
return outputString;
    }

}