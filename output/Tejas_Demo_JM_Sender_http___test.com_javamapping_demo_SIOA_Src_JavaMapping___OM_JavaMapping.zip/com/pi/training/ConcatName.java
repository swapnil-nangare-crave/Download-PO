package com.pi.training;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.sap.aii.mapping.api.AbstractTransformation;
import com.sap.aii.mapping.api.StreamTransformationException;
import com.sap.aii.mapping.api.TransformationInput;
import com.sap.aii.mapping.api.TransformationOutput;

public class ConcatName extends AbstractTransformation {
	public void transform(TransformationInput arg0, TransformationOutput arg1) throws StreamTransformationException {

		getTrace().addInfo("Java Mapping Called");

		String inData = convertStreamToString(arg0.getInputPayload().getInputStream());
		String firstName = inData.substring(inData.indexOf("<FirstName>")+11, inData.indexOf("</FirstName>"));
		String lastName = inData.substring(inData.indexOf("<LastName>")+10, inData.indexOf("</LastName>"));
		String outData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ns0:MT_Name_Target xmlns:ns0=\"http://training.com/P17.3/MappingEnhanement_00\"><FullName>"+firstName+lastName+"</FullName></ns0:MT_Name_Target>";
		try 
		{
			arg1.getOutputPayload().getOutputStream().write(outData.getBytes("UTF-8"));
		}
		catch(Exception exception1) { }
	}
	
	public String convertStreamToString(InputStream in) {
	
		StringBuffer sb = new StringBuffer();
		try
		{
			InputStreamReader isr = new InputStreamReader(in);
			Reader reader = 
				new BufferedReader(isr);
			int ch;
			while((ch = in.read() ) > -1) {
				sb.append((char)ch);
			reader.close();
			}
		}
		catch(Exception exception) { }
		return sb.toString();
	}
}