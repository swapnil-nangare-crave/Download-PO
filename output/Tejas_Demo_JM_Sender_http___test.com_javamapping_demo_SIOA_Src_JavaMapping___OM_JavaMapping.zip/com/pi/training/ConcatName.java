// 
// Decompiled by Procyon v0.6.0
// 

package com.pi.training;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import com.sap.aii.mapping.api.StreamTransformationException;
import com.sap.aii.mapping.api.TransformationOutput;
import com.sap.aii.mapping.api.TransformationInput;
import com.sap.aii.mapping.api.AbstractTransformation;

public class ConcatName extends AbstractTransformation
{
    public void transform(final TransformationInput arg0, final TransformationOutput arg1) throws StreamTransformationException {
        this.getTrace().addInfo("Java Mapping Called");
        final String inData = this.convertStreamToString(arg0.getInputPayload().getInputStream());
        final String firstName = inData.substring(inData.indexOf("<FirstName>") + 11, inData.indexOf("</FirstName>"));
        final String lastName = inData.substring(inData.indexOf("<LastName>") + 10, inData.indexOf("</LastName>"));
        final String outData = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><ns0:MT_Name_Target xmlns:ns0=\"http://training.com/P17.3/MappingEnhanement_00\"><FullName>" + firstName + lastName + "</FullName></ns0:MT_Name_Target>";
        try {
            arg1.getOutputPayload().getOutputStream().write(outData.getBytes("UTF-8"));
        }
        catch (final Exception ex) {}
    }
    
    public String convertStreamToString(final InputStream in) {
        final StringBuffer sb = new StringBuffer();
        try {
            final InputStreamReader isr = new InputStreamReader(in);
            final Reader reader = new BufferedReader(isr);
            int ch;
            while ((ch = in.read()) > -1) {
                sb.append((char)ch);
                reader.close();
            }
        }
        catch (final Exception ex) {}
        return sb.toString();
    }
}
