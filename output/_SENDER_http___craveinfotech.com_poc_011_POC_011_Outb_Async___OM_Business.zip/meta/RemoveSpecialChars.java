// 
// Decompiled by Procyon v0.6.0
// 

package meta;

import com.sap.aii.mapping.api.StreamTransformationException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import com.sap.aii.mapping.api.StreamTransformation;

public class RemoveSpecialChars implements StreamTransformation
{
    private Map param;
    
    public RemoveSpecialChars() {
        this.param = null;
    }
    
    public void setParameter(final Map param) {
        this.param = param;
        if (param == null) {
            this.param = new HashMap();
        }
    }
    
    public void execute(final InputStream inStream, final OutputStream outStream) throws StreamTransformationException {
        try {
            final BufferedReader in = new BufferedReader(new InputStreamReader(inStream));
            final BufferedWriter out = new BufferedWriter(new OutputStreamWriter(outStream));
            final Pattern p = Pattern.compile("");
            final Matcher m = p.matcher("");
            String aLine = null;
            String teste = null;
            while ((aLine = in.readLine()) != null) {
                m.reset(aLine);
                final String result = m.replaceAll("");
                teste = result.replaceAll("&lt ;", "<").trim();
                teste = teste.replaceAll(" &gt ;", ">");
                teste = result.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
                out.write(teste);
                out.newLine();
            }
            out.flush();
            in.close();
            out.close();
        }
        catch (final Exception e) {
            e.printStackTrace();
        }
    }
}
